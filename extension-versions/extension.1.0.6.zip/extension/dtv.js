document.addEventListener("DOMContentLoaded", function() {
  $scope.watchNow();
  watchNow();
});

window.onload = function() {
  $scope.watchNow();
  watchNow();
};

document.querySelector('.btn.btn-standard.btn-watch.btn-block.btn-live-strm').click();

setTimeout(function() {
	document.getElementById('flvvideo').click();
	document.body.click();
}, 30000)