var checkElementsByClassNameExists = function(id) {
	if (document.getElementsByClassName(id).length != 0) {
		document.getElementsByClassName("sign_in")[0].click()
		
	} else if (document.getElementById('fancastVideoContainer') == null) {
		setTimeout(function() {
			checkElementsByClassNameExists(id)			
		}, 1000)
	}	
}

setTimeout(function () {
	checkElementsByClassNameExists("sign_in")
}, 1000)