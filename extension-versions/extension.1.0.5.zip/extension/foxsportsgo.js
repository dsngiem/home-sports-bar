var p0 = document.getElementById('p0');
p0.classList.add("bonus");

document.documentElement.onmouseover = function() {
	var p0 = document.getElementById('p0');
	p0.classList.remove("bonus")
}

document.documentElement.onmouseout = function() {
	var p0 = document.getElementById('p0');
	p0.classList.add("bonus")
}