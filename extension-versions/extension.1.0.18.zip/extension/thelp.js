setTimeout(function() {
	document.getElementsByTagName('iframe')[0].click();
}, 5000)