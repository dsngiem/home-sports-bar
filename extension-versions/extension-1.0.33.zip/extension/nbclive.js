setTimeout(function() {
	document.querySelector("a[data-login-mvpd='Verizon']").click()
}, 15000)