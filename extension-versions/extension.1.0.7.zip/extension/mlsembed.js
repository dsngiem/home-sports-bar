var checkElementsByIdExists = function(id) {
	if (document.getElementById(id) != null) {
		document.getElementById("iptvauth_field_username").value = "dsngiem"
		document.getElementById("iptvauth_field_password").value = "gaybros"
		document.getElementsByClassName("button_small_mid")[0].click()
	} else {
		setTimeout(function() {
			checkElementsByIdExists(id)			
		}, 1000)
	}	
}

setTimeout(function() {
	checkElementsByIdExists("iptvauth_page_login")
}, 5000)