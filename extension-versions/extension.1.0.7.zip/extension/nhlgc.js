var checkElementsByIdExists = function(id) {
	if (document.getElementById(id) != null) {
		document.getElementById("user").value = "dsngiem@gmail.com"
		document.getElementById("pass").value = "chhomrith"
		document.getElementById("submit").click()
	} else {
		setTimeout(function() {
			checkElementsByIdExists(id)			
		}, 10000)
	}	
}

setTimeout(function() {
	checkElementsByIdExists("signinform")
}, 10000)