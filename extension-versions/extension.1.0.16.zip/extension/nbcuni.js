document.getElementById("player").style.width = "100%";
document.getElementById("player").style.height = "100%";
