setTimeout(function () {
	document.getElementByClassName('base-button')[0].click()
}, 5000)