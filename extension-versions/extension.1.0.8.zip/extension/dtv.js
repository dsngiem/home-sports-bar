
	document.querySelector('.btn.btn-standard.btn-watch.btn-block.btn-live-strm').click();
	//document.querySelector('.btn.btn-lg.pull-right.watch-now-btn').click();
	
if (document.getElementById('flvvideo') == null) {
	setTimeout(function() {
		document.querySelector('.btn.btn-standard.btn-watch.btn-block.btn-live-strm').click();
		//document.querySelector('.btn.btn-lg.pull-right.watch-now-btn').click();
	}, 5000)
}
