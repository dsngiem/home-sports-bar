var html = document.getElementById("${application}").innerHTML;

document.getElementById("${application}").innerHTML = html + '<param name="scale" value="default">';