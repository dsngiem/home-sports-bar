document.getElementById("flash-content-wrapper").style.width = "100%";
document.getElementById("flash-content-wrapper").style.height = "100%";
document.getElementById("flash-content-wrapper").style.position = "fixed";
document.getElementById("flash-content-wrapper").style.zIndex = "9999";
document.getElementById("flash-content-wrapper").style.left = "0px";
document.getElementById("flash-content-wrapper").style.top = "0px";


document.getElementById("scoreboard").style.display = "none";