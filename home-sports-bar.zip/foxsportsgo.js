var headers = document.getElementsByClassName("header");
for (var i = headers.length - 1; i >= 0; i--) {
	headers[i].style.display = "none";
}

document.getElementById("fsgo-content").style.width = "100%";
document.getElementById("fsgo-content").style.height = "100%";

document.getElementById("player").style.width = "100%";
document.getElementById("player").style.height = "100%";

document.getElementById("flash_object_player").style.width = "100%";
document.getElementById("flash_object_player").style.height = "100%";
